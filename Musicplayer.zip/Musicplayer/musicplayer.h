#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define ITEM char*
typedef struct st
{
    ITEM data;
    struct st *prev;
    struct st *next;
}music;

music* create(ITEM song);
void add(music** htrack,music** ttrack,ITEM song);
void play(music* track);
void traverse_next(music* pthead);
void traverse_prev(music* pttail);
void start(music* track);
music* search_by_pos(music* head_track,int pos);
music* jump(music* head_track,int pos);
void first_track(music* first);
void last_track(music* last);
void add_track_after(music* track,ITEM song,int pos);
void add_track_bef(music* track,ITEM song,int pos);
void del_any_track(music* track);
void sort_track(music** head,music** tail);
void next_track(music* first_track);
void prev_track(music* last_track);