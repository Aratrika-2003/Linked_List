//to create a music player
#include"musicplayer.h"

music* create(ITEM song)
{
	music* new_track = (music*)malloc(sizeof(music));
	
	new_track->data = strdup(song);
	new_track->next = NULL;
	new_track->prev = NULL;
	
	return new_track;
}

void add(music** htrack,music** ttrack,ITEM song)//to add the songs 
{
    music* temp = (music*)malloc(sizeof(music));

    if(*htrack == NULL)
    {
        *htrack = temp;
        *ttrack = temp;
    }
    temp->next = *htrack;
	(*htrack)->prev = temp;
	*htrack = temp;
}

void play(music* track)
{
    music* curr_track = track;
    curr_track = curr_track->next;
    printf("\nCurrently playing -> %s ",curr_track->data);
}

void traverse_next(music* pthead)
{
	while(pthead != NULL)
	{
		printf("%d ",pthead->data);
		pthead = pthead->next;
	}
	printf("\n");
}

void traverse_prev(music* pttail)
{
	while(pttail != NULL)
	{
		printf("%d ",pttail->data);
		pttail = pttail->prev;
	}
}

/*S.Start the player*/
void start(music* track)
{
    if(track == NULL)
        return;
    
    printf("%s ",track->data);
}
music* search_by_pos(music* head_track,int pos)//to search a song by position
{
    int i, c = 0;
    if(head_track == NULL)
    {
        printf("\nThe linked list is empty ");
        return NULL;
    }
    if(pos < 0)
    {
        printf("\nInvalid position ");
        return NULL;
    }
    while(head_track != NULL)
    {
        head_track = head_track->next;
        c++;
    }
    for(i = 0; i < pos - 1; i++)
    {
        head_track = head_track->next;
    }

    if(pos > c)
    {
        printf("\nInvalid position ");
        return NULL;
    }

    return head_track;
}
/*J.Jump to a specific track*/
music* jump(music* head_track,int pos)
{
    music* song;
    song = search_by_pos(head_track,pos);

    if(head_track == NULL)
        printf("\nSorry! No more songs in the playlist!!!");
    
    printf("\nThe last searched song is %s ",head_track->data);

    return song;
}
/*F.First track*/
void first_track(music* first)
{
    while(first != NULL)
    {
        printf("%s ",first->data);
        first = first->next;
    }
    printf("\n");
}
/*L.Last track*/
void last_track(music* last)
{
    if(last == NULL)
        printf("\nSorry! The searched item is not found ");
    while(last != NULL)
    {
        printf("The last track is %s ",last->data);
        last = last->prev;
    }
    printf("\n");
}

/*A.add a track after an  existing track*/
void add_track_after(music* track,ITEM song,int pos)
{
    if(track == NULL)
        return;
    
    music* temp;
    music* t;
    temp = create(song);
    t = search_by_pos(track,pos);
    temp->prev = track;
    temp->next = (track)->next;
    (track)->prev->next = temp;
    (track)->next = temp;
}
/*B.add a track before an existing track*/
void add_track_bef(music* track,ITEM song,int pos)
{
    if(track == NULL)
        return;
    
    music* temp = create(song);
    music* t;
    temp = create(song);
    t = search_by_pos(track,pos);
    temp->next = track;
    temp->prev = (track)->prev;
    (track)->next->prev = temp;
    (track)->prev = temp;
}
/*R.remove a specific track from the playlist*/
void del_any_track(music* track)
{
    track->prev->next = track->next;
    track->next->prev = track->prev;
    free(track);
}
/*O.Sort the tracks in alphabetical order*/
void sort_track(music** head,music** tail)
{
    music* curr = *head;
    music* tmp;
    music* ntmp;
    music* ncurr = curr->next;

    if(*head == NULL)
        return;
    while(ncurr != NULL)
    {
        tmp = NULL;
        ntmp = ntmp->next;
        
        while(strcmp(ntmp->data,ncurr->data)<0 && ncurr != ntmp)
        {
            tmp = ntmp;
            ntmp = ntmp->next;
        }
        if(strcmp(ntmp->data,ncurr->data)>0 && ncurr != ntmp)
        {
            curr->next = ncurr->next;
            curr->prev = ncurr;
            ncurr->next = ntmp;
            ncurr->prev = tmp;

            if(tmp == NULL)
            {
                *head = ncurr;
            }
            else
            {
                tmp->next = ncurr;
            }
            ncurr = curr->next;
        }
        else
        {
            curr = ncurr;
            ncurr = ncurr->next;
        }
    }
}

/*N.Play Next track*/
void next_track(music* first_track)
{
    if(first_track->next == NULL)
    {
        printf("\nSorry! No more songs in the playlist!!!");
        return;
    }

    while(first_track != NULL)
    {
        first_track = first_track->next;
        printf("The next track is %s ",first_track->data);
    }
}

/*P.Play Previous track*/
void prev_track(music* last_track)
{
    if(last_track == NULL)
    {
        printf("\nSearched item not found!! ");
        return;
    }

    while(last_track != NULL)
    {
        last_track = last_track->prev;
        printf("%c ",last_track->data);
    }
}