#include"musicplayer.h"

int main()
{
    FILE *fp;
    music* head = NULL;
    music* n;
    music* tail = NULL;
    music* curr = NULL;
    char song[200],ch,dummy[50],song1[50],song2[50];
    int pos,pos1,pos2;
    fp = fopen("music.txt","r");

    do
    {
        add(&head,&tail,song);
    } while (fgets(song,sizeof(song),fp),fp);

    while(1)
    {
        printf("\nPress S to start the player! ");
        printf("\nPress J to jump to a specific track! ");
        printf("\nPress N to play the next track! ");
        printf("\nPress P to play the previous track! ");
        printf("\nPress F to play the first track! ");
        printf("\nPress L to play the last track! ");
        printf("\nPress A to add a track after the existing track! ");
        printf("\nPress B to add a track before the existing track! ");
        printf("\nPress R to remove a track from the playlist! ");
        printf("\nPress O to sort the playlist in alphabetical order! ");

        printf("\nEnter your choice : ");
        scanf("%c",&ch);

        switch(ch)
        {
            case 'S': start(head);
            break;

            case 'J':
            printf("\nEnter the position where the song is to be found ");
            scanf("%d",&pos);
            n = jump(head,pos);
            break;

            case 'N':
            printf("\nThe next Track\n");
            next_track(head);
            break;

            case 'P':
            printf("\nThe previous track\n");
            prev_track(head);
            break;

            case 'F':
            printf("\nthe first track\n");
            first_track(head);
            break;

            case 'L':
            printf("\nthe last track\n");
            last_track(head);
            break;

            case 'A':
            printf("\nEnter the position where you want to add a track ");
            fgets(dummy,sizeof(dummy),stdin);
            sscanf(dummy,"%d",&pos1);
            printf("\nEnter the name of the song\n");
            fgets(song1,sizeof(song1),stdin);
            add_track_after(head,song1,pos1);
            break;

            case 'B':
            printf("\nEnter the position where you want to add a track ");
            fgets(dummy,sizeof(dummy),stdin);
            sscanf(dummy,"%d",&pos1);
            printf("\nEnter the name of the song\n");
            fgets(song2,sizeof(song2),stdin);
            add_track_after(head,song2,pos1);
            break;

            case 'R':
            printf("enter the position of the track  which you want to delete\n");
            fgets(dummy,sizeof(dummy),stdin);
            //sscanf(dummy,"%d",&pos2);
            del_any_track(head);
            break;

            case 'O':
            sort_track(&head,&tail);
            traverse_next(head);
            break;

            case 'T':
            traverse_next(head);
            break;

            default:
            break;
        }
    }
    
    fclose(fp);

    return 0;
}